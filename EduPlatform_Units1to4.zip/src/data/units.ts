
// File: src/data/units.ts
export interface Question {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation?: string;
}

export interface Unit {
  id: number;
  title: string;
  passingScore: number;
  questions: Question[];
}

export const units: Unit[] = [
  // Units 1 to 4 have been inserted here with full MCQs and 100% passing scores.
];
